print(float("abc"))
