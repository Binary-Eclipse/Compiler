name = input("Name: ")
