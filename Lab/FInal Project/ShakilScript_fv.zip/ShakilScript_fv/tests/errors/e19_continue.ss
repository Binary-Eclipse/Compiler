def f():
    continue
