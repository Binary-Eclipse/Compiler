print(len(5))
