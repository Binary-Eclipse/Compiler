print("age: " + 25)
